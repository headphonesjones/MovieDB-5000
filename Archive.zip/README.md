# Movie Database 5000 

This is the read me for the this fun little project. I hope you enjoyed my solution and hidden quirks. For example, the background image is a special tribute to some of my favorite movies. Please see the following instructions for getting the project running locally.

For your convenience I have made the app available on the following url: www.url.com/website

Also please note that basic SEO meta tags and other minor SEO and non-assignment related items were excluded from this assignment. This is not to say I do not have an understanding of these things, just that it was not required in the assignment and since this will not be a production level site it did not make much sense to add that info.

# Foundation libsass template

This is a template to start your own project that uses Grunt and libsass!

## Requirements

You'll need to have the following items installed before continuing.

  * [Node.js](http://nodejs.org): Use the installer provided on the NodeJS website.
  * [Grunt](http://gruntjs.com/): Run `[sudo] npm install -g grunt-cli`
  * [Bower](http://bower.io): Run `[sudo] npm install -g bower`

## Quickstart

```bash
git clone git@github.com:zurb/foundation-libsass-template.git
npm install && bower install
```

While you're working on your project, run:

`grunt`

And you're set!

## Directory Structure

  * `scss/_settings.scss`: Foundation configuration settings go in here
  * `scss/app.scss`: Application styles go here
